class Block{
    String nom;
    String intro;
    String quete;
    String QueFaire;
    int objectif;
    boolean decouvert;
}