class Player{
    String nom;
    int argent;
    int pv;
    int idcLignes;
    int idcColonnes;
}