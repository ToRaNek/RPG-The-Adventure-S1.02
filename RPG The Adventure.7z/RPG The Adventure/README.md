RPG The Adventure
===========

Développé par <Gordon Delangue> <Milan Theron>
Contacts : <gordondelangue7@gmail.com > , <milan.theron0@gmail.com>

# Présentation de <RPG The Adventure>
RPG The Adventure est un RPG textuelle dans le quel il est possible de se déplacer entre plusieurs block/zone constituer chacune dune quete et un defi à relever pour aller à la prochaine zone. Il est possible de réussir une épreuve après un certain nombre de question réussite, une question réussite correspond à une action réussite.

Le but du jeu est d'atteindre de réussir tout les blocks et d'avoir parcourus le monde entier du jeu(tout les blocks).

<RPG The Adventure>
Des captures d'écran illustrant le fonctionnement du logiciel sont proposées dans le répertoire shots.


# Utilisation de <RPG The Adventure>

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

```
./run.sh
```
Permet le lancement du jeu

Après cela, le jeu vous demande explicitement ce qu'il veut: votre action, si vous avez déjà ou non une sauvegarde... ect...